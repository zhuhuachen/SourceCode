package com.rm2pt.generator.springboot;

public class StaticClass {
	public static String path="java/spring/net/mydream/";
	
	public static String packagePath ="spring.net.mydream";

}
